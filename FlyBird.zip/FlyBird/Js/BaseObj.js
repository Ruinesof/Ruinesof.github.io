var baseObj = {
    randNum : function(min,max){
        return parseInt(Math.random() * (max - min +1) + min)
    },//随机数

    collide : function(obj1,obj2){
        var obj1Left = obj1.offsetLeft
        var obj1Width = obj1.offsetLeft + obj1.offsetWidth
        var obj1Top = obj1.offsetTop
        var obj1Height = obj1.offsetTop + obj1.offsetHeight
        // 获取box1的位置

        var obj2Left = obj2.offsetLeft
        var obj2Width = obj2.offsetLeft + obj2.offsetWidth
        var obj2Top = obj2.offsetTop
        var obj2Height = obj2.offsetTop + obj2.offsetHeight
        // 获取box2的位置
    }
}