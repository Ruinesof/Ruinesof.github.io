var bg = document.getElementById('bg')


// 标题抖动开始
var title = document.getElementById('title')
var bird = title.querySelector('#bird')
var Y = 3
var arr = ['./img/bird1.png', './img/bird0.png']
var index = 0

function TitleMove() {
    Y = Y * -1;
    title.style.top = title.offsetTop + Y + 'px';
    bird.src = arr[index++]
    if (index == 2) {
        index = 0
    }
}
var MoveTime = setInterval(TitleMove, 200)
// 标题抖动结束

// 草地平移开始
var grassland1 = document.getElementById('grassland1')
var grassland2 = document.getElementById('grassland2')

function GrasslanMove() {
    if (grassland1.offsetLeft <= -343) {
        grassland1.style.left = 0;
        grassland2.style.left = "100%";
    }
    grassland1.style.left = grassland1.offsetLeft - 3 + 'px'
    grassland2.style.left = grassland2.offsetLeft - 3 + 'px'
}
var LandTime = setInterval(GrasslanMove, 30)
// 草坪平移结束

// 按钮点击事件开始
var begin = document.getElementById('begin')
begin.onclick = function () {
    title.style.display = 'none'
    begin.style.display = 'none'

    // 小鸟出现
    bird.showBird();
    // 小鸟下落
    bird.birdDown()
}