var bg = document.getElementById('bg')
var BlockArr = []
var blockDistance = baseObj.randNum(120 , 350)

// 标题抖动开始
var title = document.getElementById('title')
var Bird = title.querySelector('#bird')
var Y = 3
var arr = ['./img/bird0.png', './img/bird1.png']
var index = 0

function TitleMove() {
    Y = Y * -1;
    title.style.top = title.offsetTop + Y + 'px';
    Bird.src = arr[index++]
    if (index == 2) {
        index = 0
    }
}
var MoveTime = setInterval(TitleMove, 200)
// 标题抖动结束

// 草地平移开始
var grassland1 = document.getElementById('grassland1')
var grassland2 = document.getElementById('grassland2')


function GrasslanMove() {
    if (grassland1.offsetLeft <= -343) {
        grassland1.style.left = 0;
        grassland2.style.left = "100%";
    }
    grassland1.style.left = grassland1.offsetLeft - 3 + 'px'
    grassland2.style.left = grassland2.offsetLeft - 3 + 'px'

    var blockDistance = baseObj.randNum(120 , 350)
    //管道平移
    if(BlockArr.length){
        for (let i = 0; i < BlockArr.length; i++) {
            BlockArr[i].moveBlock();    
        }
        
        if( BlockArr[BlockArr.length - 1].downDiveWarp.offsetLeft < (450 - blockDistance)){
            var newBlock = new Block()
            newBlock.crBlock()
            BlockArr.push(newBlock)

        }
    }
    
}
var LandTime = setInterval(GrasslanMove, 30)
// 草坪平移结束



// 按钮点击事件开始
var begin = document.getElementById('begin')
begin.onclick = function () {
    title.style.display = 'none'
    begin.style.display = 'none'
    clearInterval(MoveTime)//清除标题的上下移动效果,省资源

    // 小鸟出现
    bird.showBird();
    // 小鸟下落
    bird.birdDown();
    //小鸟飞行状态
    bird.WingBird();
    bg.onclick = function(){
        bird.fallDown = -8
    }
    var b= new Block()
    b.crBlock()
    BlockArr.push(b)
}