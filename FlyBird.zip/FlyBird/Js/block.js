function Block() {
    this.upDiveWarp = null;
    this.downDiveWarp = null;

    this.BlockGap = baseObj.randNum(100 , 160)//管道间的空隙
    this.DownGap = baseObj.randNum(0 , 150)//下方管道高度
    this.UpGap = 312-(this.BlockGap)-(this.DownGap)//上方管道高度
    //生成管道方法
    this.crDiv = function (url , height , PositionType , left , top ) {
        var NewDiv = document.createElement('div')
        NewDiv.style.width = '62px'
        NewDiv.style.height = height
        NewDiv.style.position = PositionType
        NewDiv.style.left = left
        NewDiv.style.top = top
        NewDiv.style.background = url

        return NewDiv;
    }

    //生成管道
    this.crBlock = function(){
        var upBlock1 = this.crDiv('url(./img/up_mod.png)' , this.UpGap + 'px' )
        var upBlock2 = this.crDiv('url(./img/up_pipe.png)' , '60px' )
        this.upDiveWarp = this.crDiv(null , null , 'absolute' , '450px' )
        this.upDiveWarp.appendChild(upBlock1)
        this.upDiveWarp.appendChild(upBlock2)//上方管道生成


        var downBlock1 = this.crDiv('url(./img/down_mod.png)' , this.DownGap + 'px' )
        var downBlock2 = this.crDiv('url(./img/down_pipe.png)' , '60px' )
        this.downDiveWarp = this.crDiv(null , null , 'absolute' , '450px' , 363 - this.DownGap + 'px')
        this.downDiveWarp.appendChild(downBlock2)
        this.downDiveWarp.appendChild(downBlock1)//下方管道生成


        bg.appendChild(this.upDiveWarp)
        bg.appendChild(this.downDiveWarp)
    }

    //管道移动
    this.moveBlock = function(){
        this.upDiveWarp.style.left = this.upDiveWarp.offsetLeft - 3 +'px'
        this.downDiveWarp.style.left = this.downDiveWarp.offsetLeft - 3 +'px'
    }
    
}