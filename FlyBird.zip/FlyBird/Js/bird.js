var bird = {
    downtime : null ,//小鸟下落时间
    div: document.createElement('div'),
    showBird: function () {
        this.div.style.width = '40px'
        this.div.style.height = '28px'
        this.div.style.background = 'url(../img/bird0.png)'
        this.div.style.backgroundRepeat = 'no-repeat'
        this.div.style.position = 'absolute'
        this.div.style.left = '50px'
        this.div.style.top = '200px'
        this.div.style.zIndex = '1'

        bg.appendChild(this.div)
    },
    fallDown: 0,
    birdDown: function () {
        bird.downtime = setInterval(fly, 60)

        function fly() {
            bird.div.style.top = bird.div.offsetTop + bird.fallDown++ + 'px';
            console.log(bird.div.offsetTop);
            if(bird.div.offsetTop > 395 ){
                console.log(bird.div.offsetHeight);
                clearInterval(bird.downtime)
            }
        }
    }
}