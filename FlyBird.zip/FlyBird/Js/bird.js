var bird = {
    downtime: null, //小鸟下落时间
    WingTime: null, //小鸟扇动翅膀

    div: document.createElement('div'),
    showBird: function () {
        this.div.style.width = '40px'
        this.div.style.height = '28px'
        this.div.style.background = 'url(./img/bird0.png)'
        this.div.style.backgroundRepeat = 'no-repeat'
        this.div.style.position = 'absolute'
        this.div.style.left = '50px'
        this.div.style.top = '200px'
        this.div.style.zIndex = '1'

        bg.appendChild(this.div)
    }, //添加小鸟
    fallDown: 0,
    birdDown: function () {
        bird.downtime = setInterval(fly, 60)

        function fly() {
            bird.div.style.top = bird.div.offsetTop + bird.fallDown++ + 'px';
            if (bird.div.offsetTop > 395 || bird.div.offsetTop <= 0) {
                clearInterval(bird.downtime)
                clearInterval(LandTime) //清除草地的移动
                clearInterval(bird.WingTime) //清除小鸟阵亡后的翅膀扇动
            }
            if (bird.fallDown >= 12) {
                bird.fallDown = 12
            }
        }
    }, //小鸟下落
    WingBird: function () {
        bird.WingTime = setInterval(wing, 120);

        var Down = ['url(./img/down_bird0.png)', 'url(./img/down_bird1.png)']
        var Up = ['url(./img/up_bird0.png)', 'url(./img/up_bird1.png)']
        var i = 0,
            j = 0

        function wing() {
            if (bird.fallDown > 0) {
                //下落
                bird.div.style.background = Down[i++]
                if (i == 2) {
                    i = 0
                }
            } else {
                //上升
                bird.div.style.background = Up[j++]
                if (j == 2) {
                    j = 0
                }

            }
        }
    } //控制小鸟翅膀摆动
}